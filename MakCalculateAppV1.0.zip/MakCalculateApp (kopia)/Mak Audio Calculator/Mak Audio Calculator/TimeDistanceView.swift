//
//  TimeDistanceView.swift
//  Mak Audio Calculator
//
//  Time/Distance calculator for audio calculations
//

import SwiftUI

enum FocusedField {
    case temperature, time, distance
}

struct TimeDistanceResult {
    let temperature: String
    let time: String
    let distance: String
}

struct TimeDistanceView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var result: TimeDistanceResult?
    @StateObject private var settings = SettingsManager.shared
    @FocusState private var focusedField: FocusedField?
    @State private var time: String = ""
    @State private var temperature: String = "20"
    @State private var distance: String = ""
    @State private var lastFocused: FocusedField?
    
    init(result: Binding<TimeDistanceResult?>) {
        self._result = result
        // Initialize fields from existing result if available
        if let existingResult = result.wrappedValue {
            // Results are stored in base units - convert to display units
            let settings = SettingsManager.shared
            let tempCelsius = Double(existingResult.temperature.replacingOccurrences(of: ",", with: ".")) ?? 20
            let distanceMeters = Double(existingResult.distance.replacingOccurrences(of: ",", with: ".")) ?? 0
            
            let tempDisplay = settings.temperatureFromCelsius(tempCelsius)
            let distanceDisplay = settings.distanceFromMeters(distanceMeters)
            
            _time = State(initialValue: existingResult.time)
            _temperature = State(initialValue: formatNumberForInit(tempDisplay))
            _distance = State(initialValue: distanceDisplay > 0 ? formatNumberForInit(distanceDisplay) : "")
        } else {
            // Set default temperature (20°C) converted to display unit
            let settings = SettingsManager.shared
            let defaultTempC = 20.0
            let defaultTempDisplay = settings.temperatureFromCelsius(defaultTempC)
            _temperature = State(initialValue: String(format: "%.0f", defaultTempDisplay))
        }
    }
    
    private func formatNumberForInit(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 5
        formatter.minimumFractionDigits = 0
        formatter.decimalSeparator = ","
        
        if let formatted = formatter.string(from: NSNumber(value: value)) {
            return formatted
        }
        return String(format: "%.5f", value).replacingOccurrences(of: ".", with: ",")
    }
    
    var body: some View {
        ZStack {
            // Light gray background
            Color(red: 0.88, green: 0.88, blue: 0.88)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Time/Distance")
                        .font(.system(size: 28, weight: .ultraLight, design: .default))
                        .tracking(-1)
                        .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                    
                    Spacer()
                    
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .frame(width: 44, height: 44)
                            .background(
                                Circle()
                                    .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                    .shadow(color: Color.black.opacity(0.15), radius: 6, x: 3, y: 3)
                                    .shadow(color: Color.white.opacity(0.8), radius: 6, x: -3, y: -3)
                            )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                // Input boxes
                VStack(spacing: 30) {
                    // Temperature input
                    InputField(label: "Temperature", value: $temperature, unit: settings.temperatureUnitSymbol(), field: .temperature, focusedField: $focusedField)
                    
                    // Time input
                    InputField(label: "Time", value: $time, unit: "s", field: .time, focusedField: $focusedField)
                    
                    // Distance input
                    InputField(label: "Distance", value: $distance, unit: settings.distanceUnitSymbol(), field: .distance, focusedField: $focusedField)
                }
                .padding(.horizontal, 20)
                .padding(.top, 50)
                .onChange(of: focusedField) { newValue in
                    // When a field loses focus (becomes nil), calculate
                    if newValue == nil && lastFocused != nil {
                        // Field lost focus, trigger calculation
                        calculate()
                        updateResult()
                    }
                    // Track which field is currently focused
                    lastFocused = newValue
                }
                .onChange(of: temperature) { _ in
                    updateResult()
                }
                .onChange(of: time) { _ in
                    updateResult()
                }
                .onChange(of: distance) { _ in
                    updateResult()
                }
                
                Spacer()
            }
        }
        .onTapGesture {
            // Dismiss keyboard when tapping outside
            focusedField = nil
        }
    }
    
    // Lookup table for speed of sound at specific temperatures
    private let speedLookup: [(temp: Double, speed: Double)] = [
        (0, 331.4),
        (5, 334.4),
        (10, 337.4),
        (15, 340.4),
        (20, 343.14),
        (25, 346.3),
        (30, 349.1),
        (40, 354.7)
    ]
    
    // Calculate speed of sound based on temperature (in Celsius) using lookup table with linear interpolation
    // Returns speed in m/s
    private func speedOfSound(temperature: Double) -> Double {
        // If temperature matches exactly, return that value
        if let exactMatch = speedLookup.first(where: { $0.temp == temperature }) {
            return exactMatch.speed
        }
        
        // Find the two points to interpolate between
        var lowerIndex = -1
        var upperIndex = -1
        
        for i in 0..<speedLookup.count {
            if speedLookup[i].temp < temperature {
                lowerIndex = i
            } else if speedLookup[i].temp > temperature && upperIndex == -1 {
                upperIndex = i
                break
            }
        }
        
        // If temperature is below the lowest value, extrapolate from first two points
        if lowerIndex == -1 {
            let first = speedLookup[0]
            let second = speedLookup[1]
            let slope = (second.speed - first.speed) / (second.temp - first.temp)
            return first.speed + slope * (temperature - first.temp)
        }
        
        // If temperature is above the highest value, extrapolate from last two points
        if upperIndex == -1 {
            let last = speedLookup[speedLookup.count - 1]
            let secondLast = speedLookup[speedLookup.count - 2]
            let slope = (last.speed - secondLast.speed) / (last.temp - secondLast.temp)
            return last.speed + slope * (temperature - last.temp)
        }
        
        // Linear interpolation between two points
        let lower = speedLookup[lowerIndex]
        let upper = speedLookup[upperIndex]
        
        let slope = (upper.speed - lower.speed) / (upper.temp - lower.temp)
        return lower.speed + slope * (temperature - lower.temp)
    }
    
    // Reverse lookup: find temperature from speed (for calculating temperature from time and distance)
    private func temperatureFromSpeed(speed: Double) -> Double? {
        // Find the two speed values to interpolate between
        var lowerIndex = -1
        var upperIndex = -1
        
        for i in 0..<speedLookup.count {
            if speedLookup[i].speed < speed {
                lowerIndex = i
            } else if speedLookup[i].speed > speed && upperIndex == -1 {
                upperIndex = i
                break
            }
        }
        
        // If speed is below the lowest value, extrapolate
        if lowerIndex == -1 {
            let first = speedLookup[0]
            let second = speedLookup[1]
            let slope = (second.speed - first.speed) / (second.temp - first.temp)
            let temp = first.temp + (speed - first.speed) / slope
            return (temp >= -10 && temp <= 50) ? temp : nil
        }
        
        // If speed is above the highest value, extrapolate
        if upperIndex == -1 {
            let last = speedLookup[speedLookup.count - 1]
            let secondLast = speedLookup[speedLookup.count - 2]
            let slope = (last.speed - secondLast.speed) / (last.temp - secondLast.temp)
            let temp = last.temp + (speed - last.speed) / slope
            return (temp >= -10 && temp <= 50) ? temp : nil
        }
        
        // Linear interpolation between two points
        let lower = speedLookup[lowerIndex]
        let upper = speedLookup[upperIndex]
        
        let slope = (upper.speed - lower.speed) / (upper.temp - lower.temp)
        let temp = lower.temp + (speed - lower.speed) / slope
        
        return (temp >= -10 && temp <= 50) ? temp : nil
    }
    
    private func calculate() {
        // Get input values and convert to base units (Celsius, meters) for calculations
        let tempDisplayValue = Double(temperature.replacingOccurrences(of: ",", with: ".")) ?? 0
        let timeValue = Double(time.replacingOccurrences(of: ",", with: ".")) ?? 0
        let distanceDisplayValue = Double(distance.replacingOccurrences(of: ",", with: ".")) ?? 0
        
        // Convert to base units for calculations
        let tempCelsius = settings.temperatureToCelsius(tempDisplayValue)
        let distanceMeters = settings.distanceToMeters(distanceDisplayValue)
        
        // Check valid ranges in base units
        let hasTemp = tempCelsius >= -10 && tempCelsius <= 50
        let hasTime = timeValue > 0
        let hasDistance = distanceMeters > 0
        
        let validFields = [hasTemp, hasTime, hasDistance].filter { $0 }.count
        
        // Need at least 2 fields to calculate the third
        guard validFields >= 2 else { return }
        
        // Calculate speed of sound in m/s (always in base units)
        let speedMetersPerSecond = speedOfSound(temperature: tempCelsius)
        
        // Priority: Calculate the field that wasn't last edited
        // If we have temperature and time, calculate distance
        if hasTemp && hasTime && lastFocused != .distance {
            let calculatedDistanceMeters = timeValue * speedMetersPerSecond
            let calculatedDistanceDisplay = settings.distanceFromMeters(calculatedDistanceMeters)
            distance = formatNumber(calculatedDistanceDisplay)
            updateResult()
        }
        // If we have temperature and distance, calculate time
        else if hasTemp && hasDistance && lastFocused != .time {
            let calculatedTime = distanceMeters / speedMetersPerSecond
            time = formatNumber(calculatedTime)
            updateResult()
        }
        // If we have time and distance, calculate temperature
        else if hasTime && hasDistance && lastFocused != .temperature {
            let speedMetersPerSecond = distanceMeters / timeValue
            if let calculatedTempCelsius = temperatureFromSpeed(speed: speedMetersPerSecond) {
                let calculatedTempDisplay = settings.temperatureFromCelsius(calculatedTempCelsius)
                temperature = formatNumber(calculatedTempDisplay)
                updateResult()
            }
        }
    }
    
    // Format number with up to 5 decimals, using comma as decimal separator
    private func formatNumber(_ value: Double) -> String {
        // Remove trailing zeros and limit to 5 decimals
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 5
        formatter.minimumFractionDigits = 0
        formatter.decimalSeparator = ","
        
        if let formatted = formatter.string(from: NSNumber(value: value)) {
            return formatted
        }
        return String(format: "%.5f", value).replacingOccurrences(of: ".", with: ",")
    }
    
    private func updateResult() {
        // Update result if we have all three values
        // Store values in base units so they can be converted when displaying
        let tempDisplayValue = Double(temperature.replacingOccurrences(of: ",", with: ".")) ?? 0
        let timeValue = Double(time.replacingOccurrences(of: ",", with: ".")) ?? 0
        let distanceDisplayValue = Double(distance.replacingOccurrences(of: ",", with: ".")) ?? 0
        
        // Convert to base units for storage
        let tempCelsius = settings.temperatureToCelsius(tempDisplayValue)
        let distanceMeters = settings.distanceToMeters(distanceDisplayValue)
        
        let hasTemp = tempCelsius >= -10 && tempCelsius <= 50
        let hasTime = timeValue > 0
        let hasDistance = distanceMeters > 0
        
        if hasTemp && hasTime && hasDistance {
            // Store in base units as strings
            result = TimeDistanceResult(
                temperature: formatNumber(tempCelsius),
                time: formatNumber(timeValue),
                distance: formatNumber(distanceMeters)
            )
        }
    }
}

struct InputField: View {
    let label: String
    @Binding var value: String
    let unit: String
    let field: FocusedField
    @FocusState.Binding var focusedField: FocusedField?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.system(size: 14, weight: .light))
                .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
            
            HStack {
                TextField("", text: $value)
                    .keyboardType(.decimalPad)
                    .font(.system(size: 18, weight: .light))
                    .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                    .focused($focusedField, equals: field)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                            .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                    )
                
                Text(unit)
                    .font(.system(size: 16, weight: .light))
                    .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                    .frame(width: 40)
            }
        }
    }
}

#Preview {
    TimeDistanceView(result: .constant(nil))
}

