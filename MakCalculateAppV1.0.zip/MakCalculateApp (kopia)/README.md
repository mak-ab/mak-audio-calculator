# MAK Audio Calculator

A native iOS audio calculator app built with SwiftUI.

## Features

- Neumorphic design interface
- Four main calculator modules:
  - Time/Distance
  - Wavelengths
  - Room Modes
  - Notes

## Setup Instructions

1. Open Xcode
2. Create a new project:
   - Choose "App" template
   - Product Name: `MakCalculateApp`
   - Interface: SwiftUI
   - Language: Swift
   - Bundle Identifier: `com.yourcompany.MakCalculateApp`

3. Replace the generated files with the files in this directory:
   - `MakCalculateAppApp.swift` - Main app entry point
   - `ContentView.swift` - Main view with calculator boxes

4. Add `Info.plist` to your project if needed (Xcode 13+ may not require it for SwiftUI apps)

5. Build and run the app on a simulator or device

## Requirements

- iOS 14.0 or later
- Xcode 12.0 or later
- Swift 5.0 or later

## Design

The app features a neumorphic design with:
- Light gray background (#EBEBEB)
- Soft shadows for depth
- Rounded corners on interactive elements
- Clean, modern typography

