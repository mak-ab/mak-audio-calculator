//
//  Mak_Audio_CalculatorApp.swift
//  Mak Audio Calculator
//
//  Created by Andreas Mäkinen on 2025-12-01.
//

import SwiftUI

@main
struct Mak_Audio_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
