//
//  WavelengthsView.swift
//  Mak Audio Calculator
//
//  Wavelengths calculator for audio calculations
//

import SwiftUI

enum WavelengthsFocusedField {
    case temperature, length, hertz
}

struct WavelengthsResult {
    let temperature: String
    let length: String
    let hertz: String
}

struct WavelengthsView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var result: WavelengthsResult?
    @StateObject private var settings = SettingsManager.shared
    @FocusState private var focusedField: WavelengthsFocusedField?
    @State private var length: String = ""
    @State private var hertz: String = ""
    @State private var temperature: String = "20"
    @State private var lastFocused: WavelengthsFocusedField?
    
    init(result: Binding<WavelengthsResult?>) {
        self._result = result
        // Initialize fields from existing result if available
        if let existingResult = result.wrappedValue {
            // Results are stored in base units - convert to display units
            let settings = SettingsManager.shared
            let tempCelsius = Double(existingResult.temperature.replacingOccurrences(of: ",", with: ".")) ?? 20
            let lengthMeters = Double(existingResult.length.replacingOccurrences(of: ",", with: ".")) ?? 0
            
            let tempDisplay = settings.temperatureFromCelsius(tempCelsius)
            let lengthDisplay = settings.distanceFromMeters(lengthMeters)
            
            _length = State(initialValue: lengthDisplay > 0 ? formatNumberForInit(lengthDisplay) : "")
            _hertz = State(initialValue: existingResult.hertz)
            _temperature = State(initialValue: formatNumberForInit(tempDisplay))
        } else {
            // Set default temperature (20°C) converted to display unit
            let settings = SettingsManager.shared
            let defaultTempC = 20.0
            let defaultTempDisplay = settings.temperatureFromCelsius(defaultTempC)
            _temperature = State(initialValue: String(format: "%.0f", defaultTempDisplay))
        }
    }
    
    private func formatNumberForInit(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 5
        formatter.minimumFractionDigits = 0
        formatter.decimalSeparator = ","
        
        if let formatted = formatter.string(from: NSNumber(value: value)) {
            return formatted
        }
        return String(format: "%.5f", value).replacingOccurrences(of: ".", with: ",")
    }
    
    var body: some View {
        ZStack {
            // Light gray background
            Color(red: 0.88, green: 0.88, blue: 0.88)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Wavelengths")
                        .font(.system(size: 28, weight: .ultraLight, design: .default))
                        .tracking(-1)
                        .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                    
                    Spacer()
                    
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .frame(width: 44, height: 44)
                            .background(
                                Circle()
                                    .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                    .shadow(color: Color.black.opacity(0.15), radius: 6, x: 3, y: 3)
                                    .shadow(color: Color.white.opacity(0.8), radius: 6, x: -3, y: -3)
                            )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                // Input boxes
                VStack(spacing: 30) {
                    // Temperature input
                    WavelengthsInputField(label: "Temperature", value: $temperature, unit: settings.temperatureUnitSymbol(), field: .temperature, focusedField: $focusedField)
                    
                    // Length input
                    WavelengthsInputField(label: "Length", value: $length, unit: settings.distanceUnitSymbol(), field: .length, focusedField: $focusedField)
                    
                    // Hertz input
                    WavelengthsInputField(label: "Hertz", value: $hertz, unit: "Hz", field: .hertz, focusedField: $focusedField)
                }
                .padding(.horizontal, 20)
                .padding(.top, 50)
                .onChange(of: focusedField) { newValue in
                    // When a field loses focus (becomes nil), calculate
                    if newValue == nil && lastFocused != nil {
                        // Field lost focus, trigger calculation
                        calculate()
                        updateResult()
                    }
                    // Track which field is currently focused
                    lastFocused = newValue
                }
                .onChange(of: temperature) { _ in
                    calculate()
                    updateResult()
                }
                .onChange(of: length) { _ in
                    calculate()
                    updateResult()
                }
                .onChange(of: hertz) { _ in
                    calculate()
                    updateResult()
                }
                
                Spacer()
            }
        }
        .onTapGesture {
            // Dismiss keyboard when tapping outside
            focusedField = nil
        }
    }
    
    // Lookup table for speed of sound at specific temperatures (same as TimeDistanceView)
    private let speedLookup: [(temp: Double, speed: Double)] = [
        (0, 331.4),
        (5, 334.4),
        (10, 337.4),
        (15, 340.4),
        (20, 343.14),
        (25, 346.3),
        (30, 349.1),
        (40, 354.7)
    ]
    
    // Calculate speed of sound based on temperature using lookup table with linear interpolation
    private func speedOfSound(temperature: Double) -> Double {
        // If temperature matches exactly, return that value
        if let exactMatch = speedLookup.first(where: { $0.temp == temperature }) {
            return exactMatch.speed
        }
        
        // Find the two points to interpolate between
        var lowerIndex = -1
        var upperIndex = -1
        
        for i in 0..<speedLookup.count {
            if speedLookup[i].temp < temperature {
                lowerIndex = i
            } else if speedLookup[i].temp > temperature && upperIndex == -1 {
                upperIndex = i
                break
            }
        }
        
        // If temperature is below the lowest value, extrapolate from first two points
        if lowerIndex == -1 {
            let first = speedLookup[0]
            let second = speedLookup[1]
            let slope = (second.speed - first.speed) / (second.temp - first.temp)
            return first.speed + slope * (temperature - first.temp)
        }
        
        // If temperature is above the highest value, extrapolate from last two points
        if upperIndex == -1 {
            let last = speedLookup[speedLookup.count - 1]
            let secondLast = speedLookup[speedLookup.count - 2]
            let slope = (last.speed - secondLast.speed) / (last.temp - secondLast.temp)
            return last.speed + slope * (temperature - last.temp)
        }
        
        // Linear interpolation between two points
        let lower = speedLookup[lowerIndex]
        let upper = speedLookup[upperIndex]
        
        let slope = (upper.speed - lower.speed) / (upper.temp - lower.temp)
        return lower.speed + slope * (temperature - lower.temp)
    }
    
    private func calculate() {
        // Get input values and convert to base units (Celsius, meters) for calculations
        let tempDisplayValue = Double(temperature.replacingOccurrences(of: ",", with: ".")) ?? 20
        let lengthDisplayValue = Double(length.replacingOccurrences(of: ",", with: ".")) ?? 0
        let hertzValue = Double(hertz.replacingOccurrences(of: ",", with: ".")) ?? 0
        
        // Convert to base units for calculations
        let tempCelsius = settings.temperatureToCelsius(tempDisplayValue)
        let lengthMeters = settings.distanceToMeters(lengthDisplayValue)
        
        // Check valid ranges in base units
        let hasTemp = tempCelsius >= -10 && tempCelsius <= 50
        let hasLength = lengthMeters > 0
        let hasHertz = hertzValue > 0
        
        let validFields = [hasTemp, hasLength, hasHertz].filter { $0 }.count
        
        // Need at least temperature and one other field
        guard hasTemp && (hasLength || hasHertz) else { return }
        
        // Calculate speed of sound in m/s (always in base units)
        let speedMetersPerSecond = speedOfSound(temperature: tempCelsius)
        
        // If we have temperature and hertz, calculate length (wavelength = speed / frequency)
        if hasHertz && lastFocused != .length {
            let calculatedLengthMeters = speedMetersPerSecond / hertzValue
            let calculatedLengthDisplay = settings.distanceFromMeters(calculatedLengthMeters)
            length = formatNumber(calculatedLengthDisplay)
        }
        // If we have temperature and length, calculate hertz (frequency = speed / wavelength)
        else if hasLength && lastFocused != .hertz {
            let calculatedHertz = speedMetersPerSecond / lengthMeters
            hertz = formatNumber(calculatedHertz)
        }
    }
    
    // Format number with up to 5 decimals, using comma as decimal separator
    private func formatNumber(_ value: Double) -> String {
        // Remove trailing zeros and limit to 5 decimals
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 5
        formatter.minimumFractionDigits = 0
        formatter.decimalSeparator = ","
        
        if let formatted = formatter.string(from: NSNumber(value: value)) {
            return formatted
        }
        return String(format: "%.5f", value).replacingOccurrences(of: ".", with: ",")
    }
    
    private func updateResult() {
        // Update result if we have all three values
        // Store values in base units so they can be converted when displaying
        let tempDisplayValue = Double(temperature.replacingOccurrences(of: ",", with: ".")) ?? 0
        let lengthDisplayValue = Double(length.replacingOccurrences(of: ",", with: ".")) ?? 0
        let hertzValue = Double(hertz.replacingOccurrences(of: ",", with: ".")) ?? 0
        
        // Convert to base units for storage
        let tempCelsius = settings.temperatureToCelsius(tempDisplayValue)
        let lengthMeters = settings.distanceToMeters(lengthDisplayValue)
        
        let hasTemp = tempCelsius >= -10 && tempCelsius <= 50
        let hasLength = lengthMeters > 0
        let hasHertz = hertzValue > 0
        
        if hasTemp && hasLength && hasHertz {
            // Store in base units as strings
            result = WavelengthsResult(
                temperature: formatNumber(tempCelsius),
                length: formatNumber(lengthMeters),
                hertz: formatNumber(hertzValue)
            )
        }
    }
}

struct WavelengthsInputField: View {
    let label: String
    @Binding var value: String
    let unit: String
    let field: WavelengthsFocusedField
    @FocusState.Binding var focusedField: WavelengthsFocusedField?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.system(size: 14, weight: .light))
                .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
            
            HStack {
                TextField("", text: $value)
                    .keyboardType(.decimalPad)
                    .font(.system(size: 18, weight: .light))
                    .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                    .focused($focusedField, equals: field)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                            .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                    )
                
                Text(unit)
                    .font(.system(size: 16, weight: .light))
                    .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                    .frame(width: 40)
            }
        }
    }
}

#Preview {
    WavelengthsView(result: .constant(nil))
}

