//
//  NotesView.swift
//  Mak Audio Calculator
//
//  Notes text editor
//

import SwiftUI

struct NotesResult {
    let text: String
}

struct NotesView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var result: NotesResult?
    @State private var notesText: String = ""
    
    init(result: Binding<NotesResult?>) {
        self._result = result
        // Initialize text from existing result if available
        if let existingResult = result.wrappedValue {
            _notesText = State(initialValue: existingResult.text)
        }
    }
    
    var body: some View {
        ZStack {
            // Light gray background
            Color(red: 0.88, green: 0.88, blue: 0.88)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Notes")
                        .font(.system(size: 28, weight: .ultraLight, design: .default))
                        .tracking(-1)
                        .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                    
                    Spacer()
                    
                    Button(action: {
                        saveAndDismiss()
                    }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .frame(width: 44, height: 44)
                            .background(
                                Circle()
                                    .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                    .shadow(color: Color.black.opacity(0.15), radius: 6, x: 3, y: 3)
                                    .shadow(color: Color.white.opacity(0.8), radius: 6, x: -3, y: -3)
                            )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                // Text editor
                TextEditor(text: $notesText)
                    .font(.system(size: 16, weight: .light))
                    .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                            .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                    )
                    .padding(.horizontal, 20)
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                    .onChange(of: notesText) { _ in
                        updateResult()
                    }
                
                Spacer()
            }
        }
    }
    
    private func saveAndDismiss() {
        updateResult()
        dismiss()
    }
    
    private func updateResult() {
        if !notesText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            result = NotesResult(text: notesText)
        } else {
            result = nil
        }
    }
}

#Preview {
    NotesView(result: .constant(nil))
}

