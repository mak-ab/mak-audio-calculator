//
//  RoomModesView.swift
//  Mak Audio Calculator
//
//  Room Modes calculator for standing waves
//

import SwiftUI

enum RoomModesFocusedField {
    case temperature, length, width, height
}

struct RoomModesResult {
    let temperature: String
    let length: String
    let width: String
    let height: String
    let frequencies: [Double]
    let threeLowest: [String]  // Three lowest frequencies as formatted strings
}

struct RoomModesView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var result: RoomModesResult?
    @StateObject private var settings = SettingsManager.shared
    @FocusState private var focusedField: RoomModesFocusedField?
    @State private var length: String = ""
    @State private var width: String = ""
    @State private var height: String = ""
    @State private var temperature: String = "20"
    @State private var calculatedFrequencies: [Double] = []
    @State private var filteredFrequencies: [Double] = []
    @State private var minFrequency: Double = 20
    @State private var maxFrequency: Double = 20000
    @State private var showResults: Bool = false
    
    private let frequencyOptions: [Double] = [0, 20, 50, 100, 500, 1000, 2000, 5000, 7500, 10000, 20000, 40000]
    
    init(result: Binding<RoomModesResult?>) {
        self._result = result
        // Initialize fields from existing result if available
        if let existingResult = result.wrappedValue {
            _length = State(initialValue: existingResult.length)
            _width = State(initialValue: existingResult.width)
            _height = State(initialValue: existingResult.height)
            _temperature = State(initialValue: existingResult.temperature)
            _calculatedFrequencies = State(initialValue: existingResult.frequencies)
            // Restore filtered frequencies and show results if we have data
            if !existingResult.frequencies.isEmpty {
                _filteredFrequencies = State(initialValue: existingResult.frequencies)
                _showResults = State(initialValue: true)
            }
        } else {
            // Set default temperature (20°C) converted to display unit
            let settings = SettingsManager.shared
            let defaultTempC = 20.0
            let defaultTempDisplay = settings.temperatureFromCelsius(defaultTempC)
            _temperature = State(initialValue: String(format: "%.0f", defaultTempDisplay))
        }
    }
    
    var body: some View {
        ZStack {
            // Light gray background
            Color(red: 0.88, green: 0.88, blue: 0.88)
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 0) {
                    // Header
                    HStack {
                        Text("Room Modes")
                            .font(.system(size: 28, weight: .ultraLight, design: .default))
                            .tracking(-1)
                            .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                        
                        Spacer()
                        
                        Button(action: {
                            dismiss()
                        }) {
                            Image(systemName: "xmark")
                                .font(.system(size: 18, weight: .light))
                                .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                .frame(width: 44, height: 44)
                                .background(
                                    Circle()
                                        .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                        .shadow(color: Color.black.opacity(0.15), radius: 6, x: 3, y: 3)
                                        .shadow(color: Color.white.opacity(0.8), radius: 6, x: -3, y: -3)
                                )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    
                    // Input boxes
                    VStack(spacing: 30) {
                        // Temperature input
                        RoomModesInputField(label: "Temperature", value: $temperature, unit: settings.temperatureUnitSymbol(), field: .temperature, focusedField: $focusedField)
                        
                        // Length input
                        RoomModesInputField(label: "Length", value: $length, unit: settings.distanceUnitSymbol(), field: .length, focusedField: $focusedField)
                        
                        // Width input
                        RoomModesInputField(label: "Width", value: $width, unit: settings.distanceUnitSymbol(), field: .width, focusedField: $focusedField)
                        
                        // Height input
                        RoomModesInputField(label: "Height", value: $height, unit: settings.distanceUnitSymbol(), field: .height, focusedField: $focusedField)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 50)
                    .onChange(of: focusedField) { newValue in
                        // When a field loses focus, clear results
                        if newValue == nil {
                            showResults = false
                            filteredFrequencies = []
                        }
                    }
                    
                    // Frequency range filters
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Show results between:")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .padding(.top, 30)
                        
                        HStack(spacing: 15) {
                            // Min frequency picker
                            VStack(alignment: .leading, spacing: 8) {
                                Text("From:")
                                    .font(.system(size: 12, weight: .light))
                                    .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                
                                Picker("", selection: $minFrequency) {
                                    ForEach(frequencyOptions, id: \.self) { freq in
                                        Text("\(Int(freq)) Hz").tag(freq)
                                    }
                                }
                                .pickerStyle(.menu)
                                .frame(maxWidth: .infinity)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 10)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                        .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                                        .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                                )
                            }
                            
                            // Max frequency picker
                            VStack(alignment: .leading, spacing: 8) {
                                Text("To:")
                                    .font(.system(size: 12, weight: .light))
                                    .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                
                                Picker("", selection: $maxFrequency) {
                                    ForEach(frequencyOptions, id: \.self) { freq in
                                        Text("\(Int(freq)) Hz").tag(freq)
                                    }
                                }
                                .pickerStyle(.menu)
                                .frame(maxWidth: .infinity)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 10)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                        .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                                        .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                                )
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    
                    // Show results button
                    Button(action: {
                        calculate()
                        filterFrequencies()
                        showResults = true
                        updateResult()
                    }) {
                        Text("Show results")
                            .font(.system(size: 16, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                    .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                                    .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                            )
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    
                    // Results section
                    if showResults && !filteredFrequencies.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Potential problem-frequencies:")
                                .font(.system(size: 16, weight: .light))
                                .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                .padding(.top, 30)
                            
                            ForEach(Array(filteredFrequencies.prefix(20).enumerated()), id: \.offset) { index, frequency in
                                HStack {
                                    Text("\(index + 1).")
                                        .font(.system(size: 14, weight: .light))
                                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                        .frame(width: 30, alignment: .leading)
                                    
                                    Text("\(formatNumber(frequency)) Hz")
                                        .font(.system(size: 14, weight: .light))
                                        .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                                }
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 20)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    }
                }
            }
        }
        .onTapGesture {
            // Dismiss keyboard when tapping outside
            focusedField = nil
        }
    }
    
    // Calculate speed of sound using formula: 331.3 + (0.606 * temperature_C)
    // Input temperature should be in Celsius, returns speed in m/s
    private func speedOfSound(temperatureCelsius: Double) -> Double {
        return 331.3 + (0.606 * temperatureCelsius)
    }
    
    private func calculate() {
        // Get input values and convert to base units (Celsius, meters) for calculations
        let tempDisplayValue = Double(temperature.replacingOccurrences(of: ",", with: ".")) ?? 20
        let lengthDisplayValue = Double(length.replacingOccurrences(of: ",", with: ".")) ?? 0
        let widthDisplayValue = Double(width.replacingOccurrences(of: ",", with: ".")) ?? 0
        let heightDisplayValue = Double(height.replacingOccurrences(of: ",", with: ".")) ?? 0
        
        // Convert to base units for calculations
        let tempCelsius = settings.temperatureToCelsius(tempDisplayValue)
        let lengthMeters = settings.distanceToMeters(lengthDisplayValue)
        let widthMeters = settings.distanceToMeters(widthDisplayValue)
        let heightMeters = settings.distanceToMeters(heightDisplayValue)
        
        // Need all dimensions to calculate (check in base units)
        guard lengthMeters > 0 && widthMeters > 0 && heightMeters > 0 && tempCelsius >= -10 && tempCelsius <= 50 else {
            calculatedFrequencies = []
            return
        }
        
        // Calculate speed of sound in m/s (always in base units)
        let speed = speedOfSound(temperatureCelsius: tempCelsius)
        
        // Calculate ALL modes for each dimension up to 40000 Hz to get comprehensive results
        // Formula: frequency_n = (speed_of_sound / 2) * (n / D)
        var allModes: [Double] = []
        
        // Calculate modes for Length until we exceed 40000 Hz
        var n = 1
        while true {
            let frequency = (speed / 2) * (Double(n) / lengthMeters)
            if frequency > 40000 { break }
            allModes.append(frequency)
            n += 1
        }
        
        // Calculate modes for Width until we exceed 40000 Hz
        n = 1
        while true {
            let frequency = (speed / 2) * (Double(n) / widthMeters)
            if frequency > 40000 { break }
            allModes.append(frequency)
            n += 1
        }
        
        // Calculate modes for Height until we exceed 40000 Hz
        n = 1
        while true {
            let frequency = (speed / 2) * (Double(n) / heightMeters)
            if frequency > 40000 { break }
            allModes.append(frequency)
            n += 1
        }
        
        // Remove duplicates and sort all modes
        let uniqueModes = Array(Set(allModes))
        calculatedFrequencies = uniqueModes.sorted()
    }
    
    private func filterFrequencies() {
        // Filter frequencies within the selected range
        filteredFrequencies = calculatedFrequencies.filter { frequency in
            frequency >= minFrequency && frequency <= maxFrequency
        }
    }
    
    // Format number with up to 5 decimals, using comma as decimal separator
    private func formatNumber(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 5
        formatter.minimumFractionDigits = 0
        formatter.decimalSeparator = ","
        
        if let formatted = formatter.string(from: NSNumber(value: value)) {
            return formatted
        }
        return String(format: "%.5f", value).replacingOccurrences(of: ".", with: ",")
    }
    
    private func updateResult() {
        let tempValue = Double(temperature.replacingOccurrences(of: ",", with: ".")) ?? 0
        let lengthValue = Double(length.replacingOccurrences(of: ",", with: ".")) ?? 0
        let widthValue = Double(width.replacingOccurrences(of: ",", with: ".")) ?? 0
        let heightValue = Double(height.replacingOccurrences(of: ",", with: ".")) ?? 0
        
        let hasTemp = tempValue >= -10 && tempValue <= 50
        let hasLength = lengthValue > 0
        let hasWidth = widthValue > 0
        let hasHeight = heightValue > 0
        
        if hasTemp && hasLength && hasWidth && hasHeight && !filteredFrequencies.isEmpty {
            // Get the three lowest frequencies
            let threeLowestFreqs = Array(filteredFrequencies.prefix(3))
            let threeLowestStrings = threeLowestFreqs.map { formatNumberOneDecimal($0) }
            
            result = RoomModesResult(
                temperature: temperature,
                length: length,
                width: width,
                height: height,
                frequencies: filteredFrequencies,
                threeLowest: threeLowestStrings
            )
        }
    }
    
    // Format number with 1 decimal, using comma as decimal separator
    private func formatNumberOneDecimal(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 1
        formatter.minimumFractionDigits = 1
        formatter.decimalSeparator = ","
        
        if let formatted = formatter.string(from: NSNumber(value: value)) {
            return formatted
        }
        return String(format: "%.1f", value).replacingOccurrences(of: ".", with: ",")
    }
}

struct RoomModesInputField: View {
    let label: String
    @Binding var value: String
    let unit: String
    let field: RoomModesFocusedField
    @FocusState.Binding var focusedField: RoomModesFocusedField?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.system(size: 14, weight: .light))
                .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
            
            HStack {
                TextField("", text: $value)
                    .keyboardType(.decimalPad)
                    .font(.system(size: 18, weight: .light))
                    .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                    .focused($focusedField, equals: field)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                            .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                    )
                
                Text(unit)
                    .font(.system(size: 16, weight: .light))
                    .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                    .frame(width: 40)
            }
        }
    }
}

#Preview {
    RoomModesView(result: .constant(nil))
}

