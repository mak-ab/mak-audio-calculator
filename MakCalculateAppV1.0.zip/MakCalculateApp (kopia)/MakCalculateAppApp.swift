//
//  MakCalculateAppApp.swift
//  MakCalculateApp
//
//  Created for MAK Audio Calculator
//

import SwiftUI

@main
struct MakCalculateAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

