//
//  SettingsManager.swift
//  Mak Audio Calculator
//
//  Settings and unit preferences manager
//

import Foundation
import SwiftUI
import Combine

enum DistanceUnit: String, CaseIterable, Codable {
    case meters = "Meters"
    case feet = "Feet"
}

enum TemperatureUnit: String, CaseIterable, Codable {
    case celsius = "Celsius"
    case fahrenheit = "Fahrenheit"
}

class SettingsManager: ObservableObject {
    static let shared = SettingsManager()
    
    @Published var distanceUnit: DistanceUnit {
        didSet {
            UserDefaults.standard.set(distanceUnit.rawValue, forKey: "distanceUnit")
        }
    }
    
    @Published var temperatureUnit: TemperatureUnit {
        didSet {
            UserDefaults.standard.set(temperatureUnit.rawValue, forKey: "temperatureUnit")
        }
    }
    
    private init() {
        // Load from UserDefaults
        if let distanceRaw = UserDefaults.standard.string(forKey: "distanceUnit"),
           let distance = DistanceUnit(rawValue: distanceRaw) {
            self.distanceUnit = distance
        } else {
            self.distanceUnit = .meters
        }
        
        if let tempRaw = UserDefaults.standard.string(forKey: "temperatureUnit"),
           let temp = TemperatureUnit(rawValue: tempRaw) {
            self.temperatureUnit = temp
        } else {
            self.temperatureUnit = .celsius
        }
    }
    
    // Convert temperature from stored unit to Celsius for calculations
    func temperatureToCelsius(_ value: Double) -> Double {
        switch temperatureUnit {
        case .celsius:
            return value
        case .fahrenheit:
            return (value - 32) * 5/9
        }
    }
    
    // Convert temperature from Celsius to display unit
    func temperatureFromCelsius(_ value: Double) -> Double {
        switch temperatureUnit {
        case .celsius:
            return value
        case .fahrenheit:
            return (value * 9/5) + 32
        }
    }
    
    // Convert distance from stored unit to meters for calculations
    func distanceToMeters(_ value: Double) -> Double {
        switch distanceUnit {
        case .meters:
            return value
        case .feet:
            return value / 3.28084
        }
    }
    
    // Convert distance from meters to display unit
    func distanceFromMeters(_ value: Double) -> Double {
        switch distanceUnit {
        case .meters:
            return value
        case .feet:
            return value * 3.28084
        }
    }
    
    // Get speed of sound in m/s (always calculated in Celsius and meters)
    func speedOfSound(temperatureCelsius: Double) -> Double {
        // Formula: v = 331.3 + (0.606 * T) where T is in Celsius
        return 331.3 + (0.606 * temperatureCelsius)
    }
    
    // Get speed of sound in display units
    func speedOfSoundDisplay(temperature: Double) -> Double {
        let tempC = temperatureToCelsius(temperature)
        let speedMeters = speedOfSound(temperatureCelsius: tempC)
        
        switch distanceUnit {
        case .meters:
            return speedMeters
        case .feet:
            return speedMeters * 3.28084 // Convert to feet per second
        }
    }
    
    // Get unit symbols
    func distanceUnitSymbol() -> String {
        return distanceUnit == .meters ? "m" : "ft"
    }
    
    func temperatureUnitSymbol() -> String {
        return temperatureUnit == .celsius ? "°C" : "°F"
    }
}

