//
//  ContentView.swift
//  MakCalculateApp
//
//  Main view with neumorphic design and calculator boxes
//

import SwiftUI

struct ContentView: View {
    @StateObject private var settings = SettingsManager.shared
    @State private var showSettings = false
    @State private var showTimeDistance = false
    @State private var showWavelengths = false
    @State private var showRoomModes = false
    @State private var showNotes = false
    @State private var timeDistanceResult: TimeDistanceResult?
    @State private var wavelengthsResult: WavelengthsResult?
    @State private var roomModesResult: RoomModesResult?
    @State private var notesResult: NotesResult?
    
    var body: some View {
        NavigationView {
            ZStack {
            // Light gray background (slightly more grey for depth)
            Color(red: 0.88, green: 0.88, blue: 0.88)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header with title and settings button
                HStack {
                    Text("MAK AUDIO CALCULATOR")
                        .font(.system(size: 28, weight: .ultraLight, design: .default))
                        .tracking(-1)
                        .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    
                    Spacer()
                    
                    Button(action: {
                        showSettings = true
                    }) {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 20, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .frame(width: 44, height: 44)
                            .background(
                                Circle()
                                    .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                    .shadow(color: Color.black.opacity(0.15), radius: 6, x: 3, y: 3)
                                    .shadow(color: Color.white.opacity(0.8), radius: 6, x: -3, y: -3)
                            )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                // Instructions
                HStack {
                    Spacer()
                    Text("Do all the basic audiocalculations now so the sound becomes better than basic.")
                        .font(.system(size: 14, weight: .light))
                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: 280)
                    Spacer()
                }
                .padding(.top, 50)
                
                // Calculator boxes grid
                VStack(spacing: 20) {
                    HStack(spacing: 20) {
                        CalculatorBox(
                            title: "Time/Distance",
                            result: timeDistanceResult,
                            wavelengthsResult: nil,
                            roomModesResult: nil,
                            notesResult: nil,
                            action: {
                                showTimeDistance = true
                            }
                        )
                        
                        CalculatorBox(
                            title: "Wavelengths",
                            result: nil,
                            wavelengthsResult: wavelengthsResult,
                            roomModesResult: nil,
                            notesResult: nil,
                            action: {
                                showWavelengths = true
                            }
                        )
                    }
                    
                    HStack(spacing: 20) {
                        CalculatorBox(
                            title: "Room Modes",
                            result: nil,
                            wavelengthsResult: nil,
                            roomModesResult: roomModesResult,
                            notesResult: nil,
                            action: {
                                showRoomModes = true
                            }
                        )
                        
                        CalculatorBox(
                            title: "Notes",
                            result: nil,
                            wavelengthsResult: nil,
                            roomModesResult: nil,
                            notesResult: notesResult,
                            action: {
                                showNotes = true
                            }
                        )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 80)
                
                Spacer()
                
                // Footer text
                VStack(spacing: 4) {
                    Text("Version 1.0")
                        .font(.system(size: 11, weight: .light))
                        .foregroundColor(Color(red: 0.5, green: 0.5, blue: 0.5))
                    
                    Text("Designed by MÄK AB for iOS")
                        .font(.system(size: 11, weight: .light))
                        .foregroundColor(Color(red: 0.5, green: 0.5, blue: 0.5))
                    
                    Text("Professional Audio Calculator")
                        .font(.system(size: 11, weight: .light))
                        .foregroundColor(Color(red: 0.5, green: 0.5, blue: 0.5))
                }
                .padding(.bottom, 30)
            }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView(
                    timeDistanceResult: $timeDistanceResult,
                    wavelengthsResult: $wavelengthsResult,
                    roomModesResult: $roomModesResult,
                    notesResult: $notesResult
                )
            }
            .fullScreenCover(isPresented: $showTimeDistance) {
                TimeDistanceView(result: $timeDistanceResult)
            }
            .fullScreenCover(isPresented: $showWavelengths) {
                WavelengthsView(result: $wavelengthsResult)
            }
            .fullScreenCover(isPresented: $showRoomModes) {
                RoomModesView(result: $roomModesResult)
            }
            .fullScreenCover(isPresented: $showNotes) {
                NotesView(result: $notesResult)
            }
        }
    }
}

struct CalculatorBox: View {
    @ObservedObject private var settings = SettingsManager.shared
    let title: String
    let result: TimeDistanceResult?
    let wavelengthsResult: WavelengthsResult?
    let roomModesResult: RoomModesResult?
    let notesResult: NotesResult?
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: title == "Notes" && notesResult != nil ? 8 : 12) {
                if let result = result, title == "Time/Distance" {
                    // Results are stored in base units (Celsius, meters) - convert to display units
                    let tempCelsius = Double(result.temperature.replacingOccurrences(of: ",", with: ".")) ?? 0
                    let distanceMeters = Double(result.distance.replacingOccurrences(of: ",", with: ".")) ?? 0
                    
                    // Convert to current display units
                    let tempDisplay = settings.temperatureFromCelsius(tempCelsius)
                    let distanceDisplay = settings.distanceFromMeters(distanceMeters)
                    
                    let tempStr = formatDisplayNumber(tempDisplay)
                    let distanceStr = formatDisplayNumber(distanceDisplay)
                    let tempSymbol = settings.temperatureUnitSymbol().replacingOccurrences(of: "°", with: "")
                    
                    Text("\(tempStr)\(tempSymbol) / \(result.time)s / \(distanceStr)\(settings.distanceUnitSymbol())")
                        .font(.system(size: 13, weight: .light))
                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                        .multilineTextAlignment(.center)
                        .lineLimit(3)
                        .padding(.horizontal, 8)
                } else if let wavelengthsResult = wavelengthsResult, title == "Wavelengths" {
                    // Results are stored in base units (Celsius, meters) - convert to display units
                    let tempCelsius = Double(wavelengthsResult.temperature.replacingOccurrences(of: ",", with: ".")) ?? 0
                    let lengthMeters = Double(wavelengthsResult.length.replacingOccurrences(of: ",", with: ".")) ?? 0
                    
                    // Convert to current display units
                    let tempDisplay = settings.temperatureFromCelsius(tempCelsius)
                    let lengthDisplay = settings.distanceFromMeters(lengthMeters)
                    
                    let tempStr = formatDisplayNumber(tempDisplay)
                    let lengthStr = formatDisplayNumber(lengthDisplay)
                    let tempSymbol = settings.temperatureUnitSymbol().replacingOccurrences(of: "°", with: "")
                    
                    Text("\(tempStr)\(tempSymbol) / \(lengthStr)\(settings.distanceUnitSymbol()) / \(wavelengthsResult.hertz)Hz")
                        .font(.system(size: 13, weight: .light))
                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                        .multilineTextAlignment(.center)
                        .lineLimit(3)
                        .padding(.horizontal, 8)
                    } else if let roomModesResult = roomModesResult, title == "Room Modes" {
                    // Show results for Room Modes: three lowest frequencies
                    if roomModesResult.threeLowest.count == 3 {
                        Text("\(roomModesResult.threeLowest[0])Hz / \(roomModesResult.threeLowest[1])Hz / \(roomModesResult.threeLowest[2])Hz")
                            .font(.system(size: 13, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .multilineTextAlignment(.center)
                            .lineLimit(3)
                            .padding(.horizontal, 8)
                    } else if roomModesResult.threeLowest.count == 2 {
                        Text("\(roomModesResult.threeLowest[0])Hz / \(roomModesResult.threeLowest[1])Hz")
                            .font(.system(size: 13, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .multilineTextAlignment(.center)
                            .lineLimit(3)
                            .padding(.horizontal, 8)
                    } else if roomModesResult.threeLowest.count == 1 {
                        Text("\(roomModesResult.threeLowest[0])Hz")
                            .font(.system(size: 13, weight: .light))
                            .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                            .multilineTextAlignment(.center)
                            .lineLimit(3)
                            .padding(.horizontal, 8)
                    }
                } else if let notesResult = notesResult, title == "Notes" {
                    // Show notes text (as much as fits in the box)
                    Text(notesResult.text)
                        .font(.system(size: 12, weight: .light))
                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                        .multilineTextAlignment(.leading)
                        .lineLimit(8)
                        .padding(.horizontal, 16)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                } else {
                    // Show plus icon for empty boxes
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .light))
                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                }
                
                Text(title)
                    .font(.system(size: 16, weight: .light))
                    .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                    .padding(.horizontal, title == "Notes" ? 16 : 0)
                    .padding(.bottom, title == "Notes" && notesResult != nil ? 12 : 0)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 180)
            .padding(title == "Notes" && notesResult != nil ? 8 : 0)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill((title == "Time/Distance" && result != nil) || 
                          (title == "Wavelengths" && wavelengthsResult != nil) ||
                          (title == "Room Modes" && roomModesResult != nil) ||
                          (title == "Notes" && notesResult != nil) ? 
                          Color(red: 0.75, green: 0.88, blue: 0.95) : // Light blue when has results (matching Pad 1)
                          Color(red: 0.88, green: 0.88, blue: 0.88)) // Default gray
                    .shadow(color: Color.black.opacity(0.2), radius: 12, x: 6, y: 6)
                    .shadow(color: Color.white.opacity(0.8), radius: 12, x: -6, y: -6)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // Format number for display (up to 2 decimals, comma separator)
    private func formatDisplayNumber(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 0
        formatter.decimalSeparator = ","
        
        if let formatted = formatter.string(from: NSNumber(value: value)) {
            return formatted
        }
        return String(format: "%.2f", value).replacingOccurrences(of: ".", with: ",")
    }
}

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var settings = SettingsManager.shared
    @Binding var timeDistanceResult: TimeDistanceResult?
    @Binding var wavelengthsResult: WavelengthsResult?
    @Binding var roomModesResult: RoomModesResult?
    @Binding var notesResult: NotesResult?
    
    init(
        timeDistanceResult: Binding<TimeDistanceResult?>,
        wavelengthsResult: Binding<WavelengthsResult?>,
        roomModesResult: Binding<RoomModesResult?>,
        notesResult: Binding<NotesResult?>
    ) {
        self._timeDistanceResult = timeDistanceResult
        self._wavelengthsResult = wavelengthsResult
        self._roomModesResult = roomModesResult
        self._notesResult = notesResult
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(red: 0.88, green: 0.88, blue: 0.88)
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Header
                    HStack {
                        Text("Settings")
                            .font(.system(size: 28, weight: .ultraLight, design: .default))
                            .tracking(-1)
                            .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.15))
                        
                        Spacer()
                        
                        Button(action: {
                            dismiss()
                        }) {
                            Image(systemName: "xmark")
                                .font(.system(size: 18, weight: .light))
                                .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                .frame(width: 44, height: 44)
                                .background(
                                    Circle()
                                        .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                        .shadow(color: Color.black.opacity(0.15), radius: 6, x: 3, y: 3)
                                        .shadow(color: Color.white.opacity(0.8), radius: 6, x: -3, y: -3)
                                )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    
                    ScrollView {
                        VStack(spacing: 30) {
                            // Unit preferences
                            VStack(alignment: .leading, spacing: 20) {
                                Text("Units")
                                    .font(.system(size: 18, weight: .light))
                                    .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                    .padding(.top, 30)
                                
                                // Distance unit picker
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Distance")
                                        .font(.system(size: 14, weight: .light))
                                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                    
                                    Picker("", selection: $settings.distanceUnit) {
                                        ForEach(DistanceUnit.allCases, id: \.self) { unit in
                                            Text(unit.rawValue).tag(unit)
                                        }
                                    }
                                    .pickerStyle(.segmented)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 10)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                                            .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                                    )
                                }
                                
                                // Temperature unit picker
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Temperature")
                                        .font(.system(size: 14, weight: .light))
                                        .foregroundColor(Color(red: 0.3, green: 0.3, blue: 0.3))
                                    
                                    Picker("", selection: $settings.temperatureUnit) {
                                        ForEach(TemperatureUnit.allCases, id: \.self) { unit in
                                            Text(unit.rawValue).tag(unit)
                                        }
                                    }
                                    .pickerStyle(.segmented)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 10)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                                            .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                                    )
                                }
                            }
                            .padding(.horizontal, 20)
                            
                            Spacer()
                            
                            // Reset buttons at bottom
                            VStack(spacing: 20) {
                                Button(action: {
                                    resetEverything()
                                }) {
                                    Text("Reset Everything")
                                        .font(.system(size: 16, weight: .light))
                                        .foregroundColor(.red)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 16)
                                        .background(
                                            RoundedRectangle(cornerRadius: 12)
                                                .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                                .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                                                .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                                        )
                                }
                                
                                Button(action: {
                                    resetEverythingExceptNotes()
                                }) {
                                    Text("Reset Everything except Notes")
                                        .font(.system(size: 16, weight: .light))
                                        .foregroundColor(.red)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 16)
                                        .background(
                                            RoundedRectangle(cornerRadius: 12)
                                                .fill(Color(red: 0.88, green: 0.88, blue: 0.88))
                                                .shadow(color: Color.black.opacity(0.15), radius: 8, x: 4, y: 4)
                                                .shadow(color: Color.white.opacity(0.8), radius: 8, x: -4, y: -4)
                                        )
                                }
                            }
                            .padding(.horizontal, 20)
                            .padding(.bottom, 30)
                        }
                    }
                }
            }
        }
    }
    
    private func resetEverything() {
        timeDistanceResult = nil
        wavelengthsResult = nil
        roomModesResult = nil
        notesResult = nil
    }
    
    private func resetEverythingExceptNotes() {
        timeDistanceResult = nil
        wavelengthsResult = nil
        roomModesResult = nil
        // Keep notesResult unchanged
    }
}

#Preview {
    ContentView()
}

